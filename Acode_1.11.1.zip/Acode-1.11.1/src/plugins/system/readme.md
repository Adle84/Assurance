# Util plugin for cordova apps

Using this plugin, cordova apps can:

- Enable/disable full screen
- Share file
- Get webview information
- Send email
- Clear cache

## Installation
