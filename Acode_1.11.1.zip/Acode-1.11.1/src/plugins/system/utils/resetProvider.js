const {
  changeProvider
} = require("./changeProvider");

changeProvider(true);