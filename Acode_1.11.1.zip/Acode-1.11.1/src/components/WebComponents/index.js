import "@ungap/custom-elements";
import WcPage from "./wcPage";

customElements.define("wc-page", WcPage);
